
# Resultados dos testes

TESTE 1 - Criando os alunos
Verificando se começaram sem matrícula e sem notas
Mostrando os alunos criados

========== SISTEMA ESCOLAR ==========
Nome: Maria Souza
Idade: 20
Curso: Sistemas de Informação
Matrícula: Inativa
Nota 1: 0.0
Nota 2: 0.0
Média: Notas ainda não cadastradas
=====================================

========== SISTEMA ESCOLAR ==========
Nome: João Silva
Idade: 16
Curso: Desenvolvimento de Sistemas
Matrícula: Inativa
Nota 1: 0.0
Nota 2: 0.0
Média: Notas ainda não cadastradas
=====================================

========== SISTEMA ESCOLAR ==========
Nome: Pedro Lima
Idade: 19
Curso: Informática
Matrícula: Inativa
Nota 1: 0.0
Nota 2: 0.0
Média: Notas ainda não cadastradas
=====================================

TESTE 2 - Realizando matrícula
Matriculando Maria
Aluno matriculado com sucesso!

========== SISTEMA ESCOLAR ==========
Nome: Maria Souza
Idade: 20
Curso: Sistemas de Informação
Matrícula: Ativa
Nota 1: 0.0
Nota 2: 0.0
Média: Notas ainda não cadastradas
=====================================

TESTE 3 - Tentando repetir a matrícula
Tentando matricular Maria novamente
Aluno já está matriculado.

========== SISTEMA ESCOLAR ==========
Nome: Maria Souza
Idade: 20
Curso: Sistemas de Informação
Matrícula: Ativa
Nota 1: 0.0
Nota 2: 0.0
Média: Notas ainda não cadastradas
=====================================

TESTE 4 - Verificando maioridade
Verificando Maria, que tem 20 anos
Aluno é maior de idade e pode participar de cursos noturnos.
Verificando João, que tem 16 anos
Aluno é menor de idade.

TESTE 5 - Cadastrando notas
Cadastrando notas 8 e 9 para Maria
Notas cadastradas com sucesso!

========== SISTEMA ESCOLAR ==========
Nome: Maria Souza
Idade: 20
Curso: Sistemas de Informação
Matrícula: Ativa
Nota 1: 8.0
Nota 2: 9.0
Média: 8.5
=====================================

TESTE 6 - Calculando média
Calculando a média da Maria
Média: 8.5

TESTE 7 - Verificando aprovação
Verificando a aprovação de Maria
Aprovado

TESTE 8 - Alterando dados do aluno
Alterando o nome de Maria Souza para Maria Oliveira
Alterando o curso de Maria

========== SISTEMA ESCOLAR ==========
Nome: Maria Oliveira
Idade: 20
Curso: Análise de Sistemas
Matrícula: Ativa
Nota 1: 8.0
Nota 2: 9.0
Média: 8.5
=====================================

TESTE 9 - Verificando aluno reprovado
Matriculando João e cadastrando notas 5 e 6
Aluno matriculado com sucesso!
Notas cadastradas com sucesso!
Reprovado

========== SISTEMA ESCOLAR ==========
Nome: João Silva
Idade: 16
Curso: Desenvolvimento de Sistemas
Matrícula: Ativa
Nota 1: 5.0
Nota 2: 6.0
Média: 5.5
=====================================

TESTE 10 - Tentando cadastrar notas inválidas
Tentando cadastrar -1 e 11 para Maria
Notas inválidas: informe valores entre 0 e 10.

========== SISTEMA ESCOLAR ==========
Nome: Maria Oliveira
Idade: 20
Curso: Análise de Sistemas
Matrícula: Ativa
Nota 1: 8.0
Nota 2: 9.0
Média: 8.5
=====================================

TESTE 11 - Consultando aluno sem notas
Consultando a média e a aprovação de Pedro
Notas ainda não cadastradas.
Notas ainda não cadastradas.
Notas não cadastradas.

========== SISTEMA ESCOLAR ==========
Nome: Pedro Lima
Idade: 19
Curso: Informática
Matrícula: Inativa
Nota 1: 0.0
Nota 2: 0.0
Média: Notas ainda não cadastradas
=====================================

TESTE 12 - Cancelando matrícula
Cancelando a matrícula de Maria
Matrícula cancelada.
Tentando cancelar novamente
Aluno já está com matrícula inativa.

========== SISTEMA ESCOLAR ==========
Nome: Maria Oliveira
Idade: 20
Curso: Análise de Sistemas
Matrícula: Inativa
Nota 1: 8.0
Nota 2: 9.0
Média: 8.5
=====================================

TODOS OS 12 TESTES FORAM CONCLUIDOS COM SUCESSO!
